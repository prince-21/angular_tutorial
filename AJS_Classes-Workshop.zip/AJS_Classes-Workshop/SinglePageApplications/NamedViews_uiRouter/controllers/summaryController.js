app.controller("summaryController",summaryController);
summaryController.$inject=["$scope"];
function summaryController($scope) {
    $scope.summary="Summary Results Soon...";
}