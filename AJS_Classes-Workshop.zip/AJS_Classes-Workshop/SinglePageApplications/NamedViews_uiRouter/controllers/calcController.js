app.controller("calcController",calcController);
calcController.$inject=["$scope"];
function calcController($scope) {
    $scope.calc = "Calculations from DB Soon....";
}